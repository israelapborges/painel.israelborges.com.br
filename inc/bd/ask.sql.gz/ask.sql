-- MySQL dump 10.13  Distrib 8.0.36-28, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: ask
-- ------------------------------------------------------
-- Server version	8.0.36-28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `dissertativas`
--

DROP TABLE IF EXISTS `dissertativas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dissertativas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime NOT NULL,
  `conteudo` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dissertativas`
--

LOCK TABLES `dissertativas` WRITE;
/*!40000 ALTER TABLE `dissertativas` DISABLE KEYS */;
INSERT INTO `dissertativas` VALUES (4,'2025-10-24 16:11:02','2. A Constituição Federal (Art. 146, III) reserva à lei complementar as normas gerais de Direito Tributário, incluindo decadência e prescrição, que vinculam todos os entes federativos.\nO prazo decadencial no lançamento de ofício é de 5 anos, contados do primeiro dia do exercício seguinte àquele em que o lançamento poderia ter sido efetuado (Art. 173, I, do CTN).\nA prescrição do direito de cobrança judicial do crédito tributário ocorre em 5 anos, contados da data da sua constituição definitiva, nos termos do Art. 174 do CTN.'),(6,'2025-10-24 23:43:20','9. A alternativa correta é a \"b\", pois em compras realizadas fora do estabelecimento comercial, o\nconsumidor pode desistir do contrato no prazo de 7 dias a contar do recebimento do produto.\nO fundamento é o direito de arrependimento, previsto no art. 49 da Lei nº 8.078/90 (CDC).\n\n10. A alternativa correta é a \"d\", pois os critérios de oralidade, simplicidade, informalidade,\neconomia processual e celeridade são os princípios que orientam o processo no Juizado.\nTal disposição está expressa no art. 2º da Lei nº 9.099/95.'),(8,'2025-10-25 00:23:44','09. A alternativa correta é a letra \"b\".\nO consumidor pode desistir do contrato no prazo de 7 dias a contar do recebimento do produto,\npois a contratação ocorreu fora do estabelecimento, com base no Art. 49 da Lei nº 8.078/90 (CDC).'),(9,'2025-10-30 19:28:11','1. É o vínculo jurídico que surge com a ocorrência do fato gerador, unindo o sujeito ativo (ente público) e o sujeito passivo (contribuinte).\nSeu objeto é a obrigação tributária principal, que consiste no pagamento de tributo ou penalidade pecuniária, nos termos do Art. 113, § 1º,\ndo Código Tributário Nacional, bem como as obrigações acessórias, que são deveres instrumentais para a fiscalização.');
/*!40000 ALTER TABLE `dissertativas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gabarito`
--

DROP TABLE IF EXISTS `gabarito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gabarito` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime NOT NULL,
  `conteudo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gabarito`
--

LOCK TABLES `gabarito` WRITE;
/*!40000 ALTER TABLE `gabarito` DISABLE KEYS */;
/*!40000 ALTER TABLE `gabarito` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-04 11:38:00
