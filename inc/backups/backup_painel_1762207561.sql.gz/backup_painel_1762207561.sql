-- MySQL dump 10.13  Distrib 8.0.36-28, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: painel
-- ------------------------------------------------------
-- Server version	8.0.36-28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `managed_databases`
--

DROP TABLE IF EXISTS `managed_databases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `managed_databases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `db_name` varchar(100) NOT NULL,
  `db_user` varchar(100) NOT NULL,
  `last_backup_file` varchar(255) DEFAULT NULL,
  `last_backup_size` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `db_name` (`db_name`),
  UNIQUE KEY `db_user` (`db_user`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `managed_databases`
--

LOCK TABLES `managed_databases` WRITE;
/*!40000 ALTER TABLE `managed_databases` DISABLE KEYS */;
INSERT INTO `managed_databases` VALUES (3,'painel','painel','backup_painel_1762207441.sql.gz',2348,'2025-11-03 21:26:58'),(4,'financeiro','financeiro','backup_financeiro_1762207501.sql.gz',11123,'2025-11-03 21:30:17');
/*!40000 ALTER TABLE `managed_databases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel_settings`
--

DROP TABLE IF EXISTS `panel_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `panel_settings` (
  `setting_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel_settings`
--

LOCK TABLES `panel_settings` WRITE;
/*!40000 ALTER TABLE `panel_settings` DISABLE KEYS */;
INSERT INTO `panel_settings` VALUES ('panel_version','1.0.0');
/*!40000 ALTER TABLE `panel_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pending_tasks`
--

DROP TABLE IF EXISTS `pending_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pending_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `payload` json NOT NULL,
  `status` enum('pending','processing','complete','failed') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `log` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pending_tasks`
--

LOCK TABLES `pending_tasks` WRITE;
/*!40000 ALTER TABLE `pending_tasks` DISABLE KEYS */;
INSERT INTO `pending_tasks` VALUES (1,'create_vhost','{\"domain\": \"papai.com.br\", \"root_path\": \"/home/papai_com_br/htdocs\", \"php_version\": \"8.1\"}','failed','Erro ao criar papai.com.br: Configuração do Nginx falhou: sh: 1: nginx: not found\n','2025-11-03 18:53:06'),(2,'delete_vhost','{\"path\": \"/etc/nginx/sites-enabled/papai.com.br.conf\", \"domain\": \"papai.com.br.conf\"}','complete','Site papai.com.br.conf excluído com sucesso.','2025-11-03 19:35:55'),(3,'create_vhost','{\"domain\": \"papai2.com.br\", \"root_path\": \"/home/papai2_com_br/htdocs\", \"php_version\": \"8.1\"}','complete','Site papai2.com.br criado com sucesso.','2025-11-03 19:37:52'),(4,'delete_vhost','{\"path\": \"/etc/nginx/sites-enabled/papai2.com.br.conf\", \"domain\": \"papai2.com.br.conf\"}','complete','Site papai2.com.br.conf excluído com sucesso.','2025-11-03 19:38:48'),(5,'create_database','{\"db_name\": \"jesus\", \"db_pass\": \"Y)2Z6dv!Ei6A$mK)\", \"db_user\": \"jesus\"}','failed','Erro ao processar (jesus): Falha ao conectar no MySQL como root: SQLSTATE[HY000] [1045] Access denied for user \'root\'@\'localhost\' (using password: YES)','2025-11-03 20:43:51'),(6,'create_database','{\"db_name\": \"Jesus\", \"db_pass\": \"KFYF*eHL(8MgiRvx\", \"db_user\": \"jesus\"}','failed','Erro ao processar (Jesus): Falha ao conectar no MySQL como root: SQLSTATE[HY000] [1045] Access denied for user \'root\'@\'localhost\' (using password: YES)','2025-11-03 20:50:39'),(7,'create_database','{\"db_name\": \"justfansa\", \"db_pass\": \"RWZVDqO7OkWFwRdz\", \"db_user\": \"aaaaaaaaaaa\"}','complete','Banco de dados \'justfansa\' e usuário \'aaaaaaaaaaa\' criados.','2025-11-03 20:52:08'),(8,'backup_database','{\"db_id\": \"1\", \"db_name\": \"justfansa\"}','complete','Backup do banco \'justfansa\' criado com sucesso.','2025-11-03 21:09:23'),(9,'delete_database','{\"db_id\": \"1\", \"db_name\": \"justfansa\", \"db_user\": \"aaaaaaaaaaa\"}','complete','Banco de dados \'justfansa\' e usuário \'aaaaaaaaaaa\' excluídos.','2025-11-03 21:10:57'),(10,'create_database','{\"db_name\": \"tester1\", \"db_pass\": \"DC%Jsr&fYKnpsaEQ\", \"db_user\": \"tester1\"}','complete','Banco de dados \'tester1\' e usuário \'tester1\' criados.','2025-11-03 21:14:55'),(11,'backup_database','{\"db_id\": \"2\", \"db_name\": \"tester1\"}','complete','Backup do banco \'tester1\' criado com sucesso.','2025-11-03 21:16:25'),(12,'backup_database','{\"db_id\": \"3\", \"db_name\": \"painel\"}','complete','Backup do banco \'painel\' criado com sucesso.','2025-11-03 21:27:44'),(13,'backup_database','{\"db_id\": \"4\", \"db_name\": \"financeiro\"}','complete','Backup do banco \'financeiro\' criado com sucesso.','2025-11-03 21:31:22'),(14,'delete_database','{\"db_id\": \"2\", \"db_name\": \"tester1\", \"db_user\": \"tester1\"}','complete','Banco de dados \'tester1\' e usuário \'tester1\' excluídos.','2025-11-03 21:51:33'),(15,'backup_database','{\"db_id\": \"3\", \"db_name\": \"painel\"}','complete','Backup do banco \'painel\' criado com sucesso.','2025-11-03 21:56:54'),(16,'backup_database','{\"db_id\": \"3\", \"db_name\": \"painel\"}','complete','Backup do banco \'painel\' criado com sucesso.','2025-11-03 22:03:58'),(17,'backup_database','{\"db_id\": \"4\", \"db_name\": \"financeiro\"}','complete','Backup do banco \'financeiro\' criado com sucesso.','2025-11-03 22:04:01'),(18,'backup_database','{\"db_id\": \"3\", \"db_name\": \"painel\"}','processing',NULL,'2025-11-03 22:05:14'),(19,'backup_database','{\"db_id\": \"4\", \"db_name\": \"financeiro\"}','processing',NULL,'2025-11-03 22:05:16');
/*!40000 ALTER TABLE `pending_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'israelborges','$2y$10$AVfh9KGBFOJSOTUVYzEdyu0gxuUJVW7xzHLFnKmwFgeY.yw26z4qe');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-03 19:06:01
