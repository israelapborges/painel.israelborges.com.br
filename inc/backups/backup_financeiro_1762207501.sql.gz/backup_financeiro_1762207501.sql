-- MySQL dump 10.13  Distrib 8.0.36-28, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: financeiro
-- ------------------------------------------------------
-- Server version	8.0.36-28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `account_transactions`
--

DROP TABLE IF EXISTS `account_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `establishment` varchar(255) NOT NULL,
  `devedor` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_month` int NOT NULL,
  `transaction_year` int NOT NULL,
  `status` enum('pago','pendente','não pago') NOT NULL DEFAULT 'pago',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_transactions`
--

LOCK TABLES `account_transactions` WRITE;
/*!40000 ALTER TABLE `account_transactions` DISABLE KEYS */;
INSERT INTO `account_transactions` VALUES (2,'2025-09-12','Financiamento Habitacional','Familia',764.00,9,2025,'pago'),(3,'2025-10-13','Financiamento Habitacional	','Familia',762.74,10,2025,'pago');
/*!40000 ALTER TABLE `account_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_tokens`
--

DROP TABLE IF EXISTS `auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `selector` varchar(255) NOT NULL,
  `validator_hash` varchar(255) NOT NULL,
  `expires` datetime NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `selector` (`selector`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `auth_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_tokens`
--

LOCK TABLES `auth_tokens` WRITE;
/*!40000 ALTER TABLE `auth_tokens` DISABLE KEYS */;
INSERT INTO `auth_tokens` VALUES (78,1,'74c5e61cb44642476983fc50b738be8c','$2y$12$CJuCGUA5Rp37WfP8It7aeeQcyI.8MvyP.MSIeTfK9Jv..4vd3ufse','2030-10-08 16:12:52','189.90.50.42'),(79,1,'bfb8b4574f3f913f9b9fcb894c00fa8c','$2y$12$CPHeEwcInSNxx0NGsS.lY.pUSsNLGg4XB0Eplsq4uHP58673IXmZq','2030-10-08 17:21:09','189.76.168.213'),(80,2,'7f23543516085641ce9f9d5579d0a9e7','$2y$12$j86cAYKWh5LaQKd3lHEAKuuptrHr7.rPaP/pM9icn3VXwVmw3AKWe','2030-10-08 17:29:05','177.174.251.17'),(81,1,'d086ea9aae31c415c50b943a571d5a45','$2y$12$wOFItvqQh3/uYYoFFRx8Q.vZrGG9e/7C3Gd1A707wae7cltrJ6Zb6','2030-10-08 19:18:20','177.53.241.81'),(82,2,'eb313899211c5780a6a15a9243315b8f','$2y$12$Aa/O49tA8tdRkOtG8orE6.z82OgRW1WffeTryk9ZphpLdpwchyGiO','2030-10-11 14:00:47','161.22.57.64');
/*!40000 ALTER TABLE `auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_transactions`
--

DROP TABLE IF EXISTS `card_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `card_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `card_id` int NOT NULL,
  `transaction_date` date NOT NULL,
  `establishment` varchar(255) NOT NULL,
  `devedor` varchar(100) DEFAULT NULL,
  `details` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `statement_month` int NOT NULL,
  `statement_year` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `card_id` (`card_id`),
  CONSTRAINT `card_transactions_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `credit_cards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10182 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_transactions`
--

LOCK TABLES `card_transactions` WRITE;
/*!40000 ALTER TABLE `card_transactions` DISABLE KEYS */;
INSERT INTO `card_transactions` VALUES (2941,2,'2025-01-02','AMAZON PRIME BR SAO PAULO(08/12)','Israel','(08/12)',13.90,8,2025),(2942,2,'2025-02-04','AMAZON BR SAO PAULO(07/15)','Israel','(07/15)',113.26,8,2025),(2943,3,'2025-08-05','•••• 3065Porto Seguro Seguros - Parcela 4/11','Ignorar','Parcela 4/11',27.50,8,2025),(2944,3,'2025-08-06','•••• 1151Uber Uber *Trip Help.U','Ignorar',NULL,12.91,8,2025),(2945,3,'2025-09-02','•••• 7528Vivo Easy*Vivo Easy','Ignorar',NULL,1.30,8,2025),(2946,3,'2025-08-15','Multa de atraso Referente ao valor em aberto de R$ 27,50 de 15/08/2025 (Valor original: R$ 27,60)','Ignorar',NULL,0.55,8,2025),(2947,1,'2025-08-03','•••• 1705Mercadolivre Motorola 50W Parcela 8/8','Israel','Parcela 8/8',50.62,8,2025),(2948,1,'2025-08-03','CVC  - Parcela 10/12','Familia','Parcela 10/12',731.10,8,2025),(2949,1,'2025-08-03','•••• 9800Mercadolivre*Gigantec - Israel - Parcela 8/10','Israel','Parcela 8/10',156.92,8,2025),(2950,1,'2025-08-03','•••• 9021Mp *Truesource Familia - Parcela 5/5','Familia','Parcela 5/5',31.90,8,2025),(2951,1,'2025-08-03','•••• 9800Mercadolivre*Ebosspag - Israel - Parcela 8/10','Israel','Parcela 8/10',32.14,8,2025),(2952,1,'2025-08-03','•••• 5568Roda Canela Familia - Parcela 2/6','Familia','Parcela 2/6',13.33,8,2025),(2953,1,'2025-08-03','•••• 3910Atacadao 303 Israel - Parcela 2/3','Israel','Parcela 2/3',30.51,8,2025),(2954,1,'2025-08-03','•••• 7761Mercadolivre*Mercadol - Google Mini Israel - Parcela 10/10','Israel','Parcela 10/10',30.90,8,2025),(2955,1,'2025-08-03','•••• 4469Mercadolivre*Mercadol - Fire stick Israel - Parcela 8/10','Israel','Parcela 8/10',44.59,8,2025),(2956,1,'2025-08-03','•••• 6648Playgames JBL - Israel - Parcela 11/12','Israel','Parcela 11/12',239.16,8,2025),(2957,1,'2025-08-03','•••• 0847Hna*O Boticario - Denise - Parcela 6/10','Denise','Parcela 6/10',28.87,8,2025),(2958,1,'2025-08-03','•••• 7761Mercadolivre*Ebazarco - Echo spot Israel - Parcela 10/10','Israel','Parcela 10/10',44.15,8,2025),(2959,1,'2025-08-03','•••• 8511Asaas *Surfseuchip - Israel - Parcela 7/12','Israel','Parcela 7/12',26.66,8,2025),(2960,1,'2025-08-03','•••• 7761Mercadolivre* SSD Mayara DF em 10x - Israel - Parcela 10/10','Israel','Parcela 10/10',30.88,8,2025),(2961,1,'2025-08-03','•••• 5808Loja Philco - Israel - Parcela 10/10','Israel','Parcela 10/10',46.78,8,2025),(2962,1,'2025-08-03','•••• 5568Snowland Participacoes Familia - Parcela 2/6','Familia','Parcela 2/6',54.83,8,2025),(2963,1,'2025-08-03','•••• 7761Mp *Truesource Familia - Parcela 6/6','Familia','Parcela 6/6',31.65,8,2025),(2964,1,'2025-08-03','•••• 7761Mercadolivre Notebook Eraldo - RecargaPay Israel - Parcela 9/10','Israel','Parcela 9/10',176.30,8,2025),(2965,1,'2025-08-03','•••• 7761 Mercadolivre*Brevisto - 2 placa mãe DC em 10x - Israel - Parcela 10/10','Israel','Parcela 10/10',71.99,8,2025),(2966,1,'2025-08-03','•••• 5735Magalu *Magazineluiza - Google Nest Israel - Parcela 10/10','Israel','Parcela 10/10',76.99,8,2025),(2967,1,'2025-08-03','•••• 1705Mercadolivre*Samsunge - 2 Powerbank Israel - Parcela 8/8','Israel','Parcela 8/8',50.19,8,2025),(2968,1,'2025-08-03','•••• 7761Mp *Samsung - Israel - Parcela 11/12','Israel','Parcela 11/12',546.38,8,2025),(2969,1,'2025-08-03','•••• 5568Hotel Termas do Lago Familia - Parcela 2/10','Familia','Parcela 2/10',155.00,8,2025),(2970,1,'2025-08-03','•••• 9800Mercadolivre*Gtech - Israel - Parcela 8/10','Israel','Parcela 8/10',34.99,8,2025),(2971,1,'2025-08-03','•••• 5038Mp *Lg Ar Condicionado 18.000btus - 12/12','Familia','Parcela 12/12',356.17,8,2025),(2972,1,'2025-08-03','•••• 4838Pg *Beleza Na Web Denise - Parcela 2/3','Denise','Parcela 2/3',82.26,8,2025),(2973,1,'2025-08-03','•••• Mercadolivre - Parcela 10/10','Israel','Parcela 10/10',118.54,8,2025),(2974,1,'2025-08-03','•••• 9800Mercadolivre 2 NVMe Arquivo - Israel - Parcela 7/10','Israel','Parcela 7/10',1337.80,8,2025),(2975,1,'2025-08-03','•••• 5568Ravena Hotel Familia - Parcela 2/3','Familia','Parcela 2/3',66.00,8,2025),(2976,1,'2025-08-03','Samsung - Shop.com - Ar - Parcela 7/12','Familia','Parcela 7/12',232.42,8,2025),(2977,1,'2025-08-03','•••• 7251Latam Air Porto galinhas Familia - Parcela 2/4','Familia','Parcela 2/4',776.47,8,2025),(2978,1,'2025-08-03','•••• 7761 Mercadolivre*Megabyte 2 Fontes DC em 10x - Israel - Parcela 10/10','Israel','Parcela 10/10',54.00,8,2025),(2979,1,'2025-08-03','•••• 6648Casas da Agua - Israel - Parcela 10/10','Israel','Parcela 10/10',59.50,8,2025),(2980,1,'2025-08-03','•••• 5038Mp *Lgelectronics - Israel - Parcela 11/12','Israel','Parcela 11/12',126.60,8,2025),(2981,1,'2025-08-03','•••• 3831Qconcursos Israel - Parcela 3/12','Israel','Parcela 3/12',45.00,8,2025),(2982,1,'2025-08-03','•••• 7761Mercadolivre*Mercadol - Alexa Israel - Parcela 10/10','Israel','Parcela 10/10',90.90,8,2025),(2983,1,'2025-08-03','•••• 9800Mercadolivre*54108951 - Israel - Parcela 8/10','Israel','Parcela 8/10',45.97,8,2025),(2984,1,'2025-08-03','•••• 9800Mercadolivre*Setupnin - Israel - Parcela 8/8','Israel','Parcela 8/8',32.48,8,2025),(2985,1,'2025-08-03','•••• 7761Mercadolivre*Alpha - 2 SSD DC em 10x - Israel - Parcela 10/10','Israel','Parcela 10/10',35.36,8,2025),(2986,1,'2025-08-03','•••• 6222Hub*Netshoes - 3 tênis Israel - Parcela 10/12','Israel','Parcela 10/12',66.10,8,2025),(2987,1,'2025-08-03','•••• 6566Mercadolivre*2produto Denise - Parcela 4/4','Denise','Parcela 4/4',30.78,8,2025),(2988,1,'2025-08-03','•••• 7761Mercadolivre - Mikrotik Israel - Parcela 7/10','Israel','Parcela 7/10',90.00,8,2025),(2989,1,'2025-08-03','•••• 7761Mercadopago Truesource Familia - Parcela 3/6','Familia','Parcela 3/6',58.24,8,2025),(2990,1,'2025-08-03','•••• 3069Hub*Netshoes - Israel - Parcela 8/8','Israel','Parcela 8/8',53.99,8,2025),(2991,1,'2025-08-03','•••• 3910Atacadao 303 Israel - Parcela 3/3','Israel','Parcela 3/3',20.97,8,2025),(2992,1,'2025-08-03','•••• 9800 Mercadolivre*2produto - placa-mae e processador DA - Israel - Parcela 7/10','Israel','Parcela 7/10',92.81,8,2025),(2993,1,'2025-08-03','•••• 9800Mercadolivre*Gigantec - Israel - Parcela 8/10','Israel','Parcela 8/10',48.44,8,2025),(2994,1,'2025-08-03','•••• 9800Mercadolivre*Dairoapa DP Arquivo Israel - Parcela 4/12','Israel','Parcela 4/12',99.09,8,2025),(2995,1,'2025-08-03','•••• 7761Mercadolivre*Lvmoveis sapateira - Família - Parcela 10/10','Familia','Parcela 10/10',28.15,8,2025),(2996,1,'2025-08-03','•••• 9800Mercadolivre*Megabyte placa-video DF - Israel - Parcela 7/9','Israel','Parcela 7/9',52.21,8,2025),(2997,1,'2025-08-03','•••• 9800 Mercadolivre*6produto - Arquivo placa-mae e memória Israel - Parcela 8/10','Israel','Parcela 8/10',82.04,8,2025),(2998,1,'2025-08-03','•••• 2716Shopee *Drcxeletronico em 12x Amazfit Israel - Parcela 10/12','Israel','Parcela 10/12',124.91,8,2025),(2999,1,'2025-08-03','•••• 7761Mercadolivre*2produto - Parcela 10/10','Israel','Parcela 10/10',61.33,8,2025),(3000,1,'2025-08-03','•••• 9800Mercadolivre nvme Lab Israel - Parcela 3/11','Israel','Parcela 3/11',51.59,8,2025),(3001,1,'2025-08-03','•••• 3910Atacadao 303 Israel - Parcela 3/3','Israel','Parcela 3/3',19.93,8,2025),(3002,1,'2025-08-03','•••• 1705Hub*Netshoes - 3 novos tênis Israel - Parcela 8/12','Israel','Parcela 8/12',67.86,8,2025),(3003,1,'2025-08-03','•••• 3172Zurich Seguros Familia - Parcela 4/12','Familia','Parcela 4/12',32.47,8,2025),(3004,1,'2025-08-03','•••• 6566Drogaria_sp epiduo Denise - Parcela 3/3','Denise','Parcela 3/3',101.64,8,2025),(3005,1,'2025-08-03','•••• 8171Passei Direto 12x de 39,90 - Vitalicio Israel - Parcela 3/12','Israel','Parcela 3/12',39.90,8,2025),(3006,1,'2025-08-03','•••• 7761Mp *Truesource Familia - Parcela 4/6','Familia','Parcela 4/6',31.65,8,2025),(3007,1,'2025-08-03','•••• 9800Mp *Pichauinformatica - Israel - Parcela 8/10','Israel','Parcela 8/10',36.90,8,2025),(3008,1,'2025-08-03','•••• 5568Mini Mundo Comercio Familia - Parcela 2/2','Familia','Parcela 2/2',58.00,8,2025),(3009,1,'2025-08-03','•••• 7761Mercadolivre*3produto - Arquivo Israel - Parcela 10/10','Israel','Parcela 10/10',33.28,8,2025),(3010,1,'2025-08-03','•••• 9800Mercadolivre*2produto DC Arquivo Israel - Parcela 4/12','Israel','Parcela 4/12',137.74,8,2025),(3011,1,'2025-08-03','•••• 0348Hub*Zattini Denise - Parcela 5/8','Denise','Parcela 5/8',54.78,8,2025),(3012,1,'2025-08-03','•••• 0348Mc Via Parque Israel - Parcela 5/10','Israel','Parcela 5/10',159.20,8,2025),(3013,1,'2025-08-03','•••• 4838Ultrafarma Saude Eirel - Israel - Parcela 2/3','Israel','Parcela 2/3',47.90,8,2025),(3014,1,'2025-08-03','•••• 7761Mercadolivre*Mercadol - Alexa 8 gen3 - Israel - Parcela 10/10','Israel','Parcela 10/10',100.50,8,2025),(3015,1,'2025-08-05','•••• 3910Rest e Lanch Elohin Familia','Familia',NULL,5.50,8,2025),(3016,1,'2025-08-05','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,8.99,8,2025),(3017,1,'2025-08-06','•••• 4927Cobasi Barreiros Familia','Familia',NULL,58.49,8,2025),(3018,1,'2025-08-06','•••• 6566Hai Toyota Familia - Parcela 1/6','Familia','Parcela 1/6',256.65,8,2025),(3019,1,'2025-08-06','•••• 3910Mesa Posta Cafe Israel','Israel',NULL,10.90,8,2025),(3020,1,'2025-08-06','•••• 3910Big Pan Padaria Familia','Familia',NULL,7.46,8,2025),(3021,1,'2025-08-07','•••• 3910Giassi Supermercados Familia','Familia',NULL,217.40,8,2025),(3022,1,'2025-08-07','•••• 5074Allianz Seguros Familia','Familia',NULL,186.24,8,2025),(3023,1,'2025-08-07','•••• 3910Minimercado Fronza Familia','Familia',NULL,16.00,8,2025),(3024,1,'2025-08-07','•••• 6566Yumi Cosmeticos Denise','Denise',NULL,24.00,8,2025),(3025,1,'2025-08-09','•••• 7622Visualmind App','Israel',NULL,6.43,8,2025),(3026,1,'2025-08-10','•••• 3910Cobasi Barreiros Familia','Familia',NULL,121.20,8,2025),(3027,1,'2025-08-10','•••• 3910Ellius Restaurante Israel','Israel',NULL,59.90,8,2025),(3028,1,'2025-08-10','•••• 6566Vetvida Familia','Familia',NULL,267.00,8,2025),(3029,1,'2025-08-10','•••• 3910Ellius Restaurante Denise','Denise',NULL,28.67,8,2025),(3030,1,'2025-08-10','•••• 3910Coelho Mercearia Familia','Familia',NULL,6.49,8,2025),(3031,1,'2025-08-11','•••• 6566Mercadopago *Shellbox Familia','Familia',NULL,219.12,8,2025),(3032,1,'2025-08-11','•••• 3910Super Imperatriz Familia','Familia',NULL,70.75,8,2025),(3033,1,'2025-08-11','•••• 5434Uber Israel','Israel',NULL,30.93,8,2025),(3034,1,'2025-08-12','•••• 2393Sim.Digital Familia','Familia',NULL,129.80,8,2025),(3035,1,'2025-08-12','•••• 3910Zp*Restaurante Tropical Familia','Familia',NULL,116.00,8,2025),(3036,1,'2025-08-13','•••• 9358Jusbrasil Familia','Familia',NULL,1.90,8,2025),(3037,1,'2025-08-13','•••• 3910Valdetepaesmarcon Israel','Israel',NULL,6.00,8,2025),(3038,1,'2025-08-14','•••• 3910Postos Ultra Israel','Israel',NULL,15.98,8,2025),(3039,1,'2025-08-14','•••• 3910Valdetepaesmarcon Israel','Israel',NULL,6.00,8,2025),(3040,1,'2025-08-14','•••• 3910Mundocar Familia','Familia',NULL,1.00,8,2025),(3041,1,'2025-08-14','•••• 3910Prado Supermercado Familia','Familia',NULL,33.21,8,2025),(3042,1,'2025-08-14','•••• 6566Prado Supermercado Denise','Denise',NULL,10.46,8,2025),(3043,1,'2025-08-14','•••• 6566Postos Ultra Denise','Denise',NULL,4.99,8,2025),(3044,1,'2025-08-15','•••• 3910Mesa Posta Cafe Israel','Israel',NULL,20.30,8,2025),(3045,1,'2025-08-15','•••• 3910Giassi Supermercados Familia','Familia',NULL,134.18,8,2025),(3046,1,'2025-08-15','•••• 3910Arena Kobrasol Denise','Denise',NULL,5.00,8,2025),(3047,1,'2025-08-16','•••• 4050Rdsaude Online Denise','Denise',NULL,81.99,8,2025),(3048,1,'2025-08-16','•••• 3910Prado Supermercado Familia','Familia',NULL,54.55,8,2025),(3049,1,'2025-08-18','•••• 5434Uber Israel','Israel',NULL,25.92,8,2025),(3050,1,'2025-08-18','•••• 3910Sao Joao Farmacias Israel','Israel',NULL,52.80,8,2025),(3051,1,'2025-08-19','•••• 3910Restaurante Estacao Israel','Israel',NULL,18.27,8,2025),(3052,1,'2025-08-19','•••• 3910Restaurante Estacao Denise','Denise',NULL,25.33,8,2025),(3053,1,'2025-08-19','•••• 3910Restaurante Tropical Familia','Familia',NULL,122.00,8,2025),(3054,1,'2025-08-20','•••• 3910Pague Menos Israel','Israel',NULL,34.46,8,2025),(3055,1,'2025-08-21','Nu Seguro Vida','Israel',NULL,20.74,8,2025),(3056,1,'2025-08-21','•••• 3910Prado Supermercado Israel','Israel',NULL,30.70,8,2025),(3057,1,'2025-08-22','•••• 3910Tlb Pizzaria','Familia',NULL,96.23,8,2025),(3058,1,'2025-08-22','•••• 3910Minimercado Fronza Familia','Familia',NULL,1.59,8,2025),(3059,1,'2025-08-22','•••• 3910Mesa Posta Cafe Israel','Israel',NULL,5.00,8,2025),(3060,1,'2025-08-22','•••• 3910Postos Ultra Israel','Israel',NULL,13.98,8,2025),(3061,1,'2025-08-22','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,11.99,8,2025),(3062,1,'2025-08-22','•••• 3910Arena Kobrasol Denise','Denise',NULL,5.00,8,2025),(3063,1,'2025-08-22','•••• 3910Mesa Posta Cafe Israel','Israel',NULL,10.90,8,2025),(3064,1,'2025-08-22','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,4.99,8,2025),(3065,1,'2025-08-23','•••• 3910Supermercados Imperatriz Familia','Familia',NULL,5.83,8,2025),(3066,1,'2025-08-23','•••• 3910Supermercados Imperatriz Israel','Israel',NULL,19.59,8,2025),(3067,1,'2025-08-23','•••• 2458Google Youtubepremium Familia','Familia',NULL,16.90,8,2025),(3068,1,'2025-08-23','•••• 9800Mercadolivre*Bwgshop Denise - Parcela 1/12','Denise','Parcela 1/12',224.00,8,2025),(3069,1,'2025-08-24','•••• 5434Uber Israel','Israel',NULL,25.96,8,2025),(3070,1,'2025-08-25','•••• 3910Giassi Supermercados Israel','Israel',NULL,26.86,8,2025),(3071,1,'2025-08-25','•••• 3910Itaguacu Administrado Familia','Familia',NULL,16.00,8,2025),(3072,1,'2025-08-25','•••• 3910Restaurante Estacao Denise','Denise',NULL,31.77,8,2025),(3073,1,'2025-08-25','•••• 3910Farmacia Preco Popular Familia','Familia',NULL,38.59,8,2025),(3074,1,'2025-08-25','•••• 3910Giassi Supermercados Familia','Familia',NULL,131.35,8,2025),(3075,1,'2025-08-25','•••• 3910Multicine Sao Jose Familia','Familia',NULL,76.00,8,2025),(3076,1,'2025-08-25','•••• 3910Restaurante Estacao Israel','Israel',NULL,54.77,8,2025),(3077,1,'2025-08-26','•••• 6566Ec *Shellbox Familia','Familia',NULL,210.55,8,2025),(3078,1,'2025-08-26','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,20.98,8,2025),(3079,1,'2025-08-26','•••• 3910Restaurante Israel','Israel',NULL,4.00,8,2025),(3080,1,'2025-08-28','•••• 3910Drogaria Catarinense Familia','Familia',NULL,64.09,8,2025),(3081,1,'2025-08-28','•••• 3910Minimercado Fronza Familia','Familia',NULL,33.93,8,2025),(3082,1,'2025-08-29','•••• 3910Arena Kobrasol Israel','Israel',NULL,11.00,8,2025),(3083,1,'2025-08-29','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,13.98,8,2025),(3084,1,'2025-08-29','•••• 3910Rest e Lanch Elohin Israel','Israel',NULL,13.00,8,2025),(3085,1,'2025-08-29','•••• 3910Arena Kobrasol Denise','Denise',NULL,5.00,8,2025),(3086,1,'2025-08-29','•••• 2968Tokio Marine*Vidi04d12 Israel','Israel',NULL,42.45,8,2025),(3087,1,'2025-08-30','•••• 6566Correio*Correios Cel Denise','Denise',NULL,30.00,8,2025),(3088,1,'2025-08-30','•••• 3910Skynas Bar Denise','Denise',NULL,6.00,8,2025),(3089,1,'2025-08-30','•••• 3910Adriana Cabeleileiro Israel','Israel',NULL,30.00,8,2025),(3090,1,'2025-08-30','•••• 3910Skynas Bar Israel','Israel',NULL,16.50,8,2025),(3091,1,'2025-08-31','•••• 3910Di Boldrini Restauran Israel','Israel',NULL,35.80,8,2025),(3092,1,'2025-08-31','•••• 3910Di Boldrini Restauran Denise','Denise',NULL,29.90,8,2025),(3093,1,'2025-08-31','•••• 3910Chiquinho Sorvetes Israel','Israel',NULL,5.50,8,2025),(3094,1,'2025-08-31','•••• 6566Chiquinho Sorvetes Denise','Denise',NULL,5.50,8,2025),(3095,1,'2025-08-31','•••• 6566Prado Supermercado Familia','Familia',NULL,52.14,8,2025),(3096,1,'2025-08-31','•••• 6566Prado Supermercado Familia','Familia',NULL,22.59,8,2025),(3097,1,'2025-09-01','•••• 5434Pop 30ago 18h52min Israel','Israel',NULL,27.70,8,2025),(3098,1,'2025-09-02','•••• 4871Vivo Easy*Vivo Easy Israel','Israel',NULL,1.30,8,2025),(3099,1,'2025-09-02','•••• 3910Mesa Posta Cafe Israel','Israel',NULL,13.50,8,2025),(3100,1,'2025-09-02','•••• 3910Mesa Posta Cafe Israel','Israel',NULL,10.90,8,2025),(3101,1,'2025-09-02','•••• 4871Vivo Easy*Vivo Easy Israel','Israel',NULL,1.30,8,2025),(3102,1,'2025-09-02','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,4.99,8,2025),(3103,1,'2025-09-02','•••• 6566Giassi Supermercados Familia','Familia',NULL,141.35,8,2025),(3104,1,'2025-10-06','•••• 7622Visualmind App IOF',NULL,'N/A',0.22,10,2025),(3105,1,'2025-08-09','•••• 7622Visualmind App IOF','Israel','N/A',0.22,8,2025),(3242,3,'2025-09-05','•••• 3065Porto Seguro Seguros - Parcela 5/11','Denise','Parcela 5/11',27.50,9,2025),(3243,2,'2025-01-02','AMAZON PRIME BR SAO PAULO(09/12)','Israel','(09/12)',13.90,9,2025),(3244,2,'2025-02-04','AMAZON BR SAO PAULO(08/15)','Israel','(08/15)',113.26,9,2025),(9762,1,'2025-09-03','•••• 9800Mercadolivre*Gigantec - Israel - Parcela 9/10','Israel','Parcela 9/10',156.92,9,2025),(9763,1,'2025-09-03','CVC- NuPay - Parcela 11/12','Familia','Parcela 11/12',731.10,9,2025),(9764,1,'2025-09-03','•••• 6648Playgames JBL - Israel - Parcela 12/12','Israel','Parcela 12/12',239.16,9,2025),(9765,1,'2025-09-03','•••• 9800Mercadolivre*Ebosspag - Israel - Parcela 9/10','Israel','Parcela 9/10',32.14,9,2025),(9766,1,'2025-09-03','•••• 4469Mercadolivre*Mercadol - Fire stick Israel - Parcela 9/10','Israel','Parcela 9/10',44.59,9,2025),(9767,1,'2025-09-03','•••• 0847Hna*O Boticario - Denise - Parcela 7/10','Denise','Parcela 7/10',28.87,9,2025),(9768,1,'2025-09-03','•••• 3910Atacadao 303 Israel - Parcela 3/3','Israel','Parcela 3/3',30.51,9,2025),(9769,1,'2025-09-03','•••• 8511Asaas *Surfseuchip - Israel - Parcela 8/12','Israel','Parcela 8/12',26.66,9,2025),(9770,1,'2025-09-03','•••• 5568Snowland Participacoes Familia - Parcela 3/6','Familia','Parcela 3/6',54.83,9,2025),(9771,1,'2025-09-03','•••• 7761Mp *Samsung - Israel - Parcela 12/12','Israel','Parcela 12/12',546.38,9,2025),(9772,1,'2025-09-03','•••• 5568Hotel Termas do Lago Familia - Parcela 3/10','Familia','Parcela 3/10',155.00,9,2025),(9773,1,'2025-09-03','•••• 6566Hai Toyota Familia - Parcela 2/6','Familia','Parcela 2/6',256.61,9,2025),(9774,1,'2025-09-03','•••• 7761Mercadolivre Notebook Eraldo - RecargaPay Israel - Parcela 10/10','Israel','Parcela 10/10',176.30,9,2025),(9775,1,'2025-09-03','•••• 5038Mp *Lgelectronics - Israel - Parcela 12/12','Israel','Parcela 12/12',126.60,9,2025),(9776,1,'2025-09-03','•••• 9800Mercadolivre*Gtech - Israel - Parcela 9/10','Israel','Parcela 9/10',34.99,9,2025),(9777,1,'2025-09-03','•••• 4838Pg *Beleza Na Web Denise - Parcela 3/3','Denise','Parcela 3/3',82.26,9,2025),(9778,1,'2025-09-03','•••• 7761Mercadopago Truesource Familia - Parcela 4/6','Familia','Parcela 4/6',58.24,9,2025),(9779,1,'2025-09-03','•••• 9800Mercadolivre 2 NVMe Arquivo - Israel - Parcela 8/10','Israel','Parcela 8/10',1337.80,9,2025),(9780,1,'2025-09-03','•••• 7251Latam Air Porto galinhas Familia - Parcela 3/4','Familia','Parcela 3/4',776.47,9,2025),(9781,1,'2025-09-03','•••• 3910Minimercado Fronza Familia','Familia',NULL,3.50,9,2025),(9782,1,'2025-09-03','Samsung - Shop.com - AR - Parcela 8/12','Familia','Parcela 8/12',232.42,9,2025),(9783,1,'2025-09-03','•••• 5568Ravena Hotel Familia - Parcela 3/3','Familia','Parcela 3/3',66.00,9,2025),(9784,1,'2025-09-03','•••• 9800Mercadolivre*54108951 - Israel - Parcela 9/10','Israel','Parcela 9/10',45.97,9,2025),(9785,1,'2025-09-03','•••• 4838Ultrafarma Saude Eirel - Israel - Parcela 3/3','Israel','Parcela 3/3',47.90,9,2025),(9786,1,'2025-09-03','•••• 6222Hub*Netshoes - 3 tênis Israel - Parcela 11/12','Israel','Parcela 11/12',66.10,9,2025),(9787,1,'2025-09-03','•••• 3831Qconcursos Israel - Parcela 4/12','Israel','Parcela 4/12',45.00,9,2025),(9788,1,'2025-09-03','•••• 7761Mercadolivre - Mikrotik Israel - Parcela 8/10','Israel','Parcela 8/10',90.00,9,2025),(9789,1,'2025-09-03','•••• 9800Mercadolivre*Gigantec - Israel - Parcela 9/10','Israel','Parcela 9/10',48.44,9,2025),(9790,1,'2025-09-03','•••• 9800 Mercadolivre*2produto - placa-mae e processador DA - Israel - Parcela 8/10','Israel','Parcela 8/10',92.81,9,2025),(9791,1,'2025-09-03','•••• 9800Mercadolivre*Dairoapa DP Arquivo Israel - Parcela 5/12','Israel','Parcela 5/12',99.09,9,2025),(9792,1,'2025-09-03','•••• 9800Mercadolivre*Megabyte placa-video DF - Israel - Parcela 8/9','Israel','Parcela 8/9',52.21,9,2025),(9793,1,'2025-09-03','•••• 9800 Mercadolivre*6produto - Arquivo placa-mae e memória Israel - Parcela 9/10','Israel','Parcela 9/10',82.04,9,2025),(9794,1,'2025-09-03','•••• 9800Mercadolivre nvme Lab Israel - Parcela 4/11','Israel','Parcela 4/11',51.59,9,2025),(9795,1,'2025-09-03','•••• 2716Shopee *Drcxeletronico em 12x Amazfit Israel - Parcela 11/12','Israel','Parcela 11/12',124.91,9,2025),(9796,1,'2025-09-03','•••• 3172Zurich Seguros Familia - Parcela 5/12','Familia','Parcela 5/12',32.47,9,2025),(9797,1,'2025-09-03','•••• 8171Passei Direto 12x de 39,90 - Vitalicio Israel - Parcela 4/12','Israel','Parcela 4/12',39.90,9,2025),(9798,1,'2025-09-03','•••• 7761Mp *Truesource Familia - Parcela 5/6','Familia','Parcela 5/6',31.65,9,2025),(9799,1,'2025-09-03','•••• 9800Mp *Pichauinformatica - Israel - Parcela 9/10','Israel','Parcela 9/10',36.90,9,2025),(9800,1,'2025-09-03','•••• 5568Roda Canela Familia - Parcela 3/6','Familia','Parcela 3/6',13.33,9,2025),(9801,1,'2025-09-03','•••• 9800Mercadolivre*Bwgshop Denise - Parcela 2/12','Denise','Parcela 2/12',223.90,9,2025),(9802,1,'2025-09-03','•••• 0348Hub*Zattini Denise - Parcela 6/8','Denise','Parcela 6/8',54.78,9,2025),(9803,1,'2025-09-03','•••• 9800Mercadolivre*2produto DC Arquivo Israel - Parcela 5/12','Israel','Parcela 5/12',137.74,9,2025),(9804,1,'2025-09-03','•••• 0348Mc Via Parque Israel - Parcela 6/10','Israel','Parcela 6/10',159.20,9,2025),(9805,1,'2025-09-03','•••• 1705Hub*Netshoes - 3 novos tênis Israel - Parcela 9/12','Israel','Parcela 9/12',67.86,9,2025),(9806,1,'2025-09-04','•••• 3910Imbituba Lanches Denise','Denise',NULL,33.50,9,2025),(9807,1,'2025-09-04','•••• 4927Cobasi Barreiros Familia','Familia',NULL,59.70,9,2025),(9808,1,'2025-09-04','•••• 3910Imbituba Lanches Israel','Israel',NULL,35.50,9,2025),(9809,1,'2025-09-04','•••• 6566Fort Atacadista Denise','Denise',NULL,31.88,9,2025),(9810,1,'2025-09-04','•••• 6566Fort Atacadista Familia','Familia',NULL,416.93,9,2025),(9811,1,'2025-09-05','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,4.99,9,2025),(9812,1,'2025-09-05','•••• 5434Uber Israel','Israel',NULL,11.93,9,2025),(9813,1,'2025-09-06','•••• 3910Mk Barreiros Israel','Israel',NULL,12.00,9,2025),(9814,1,'2025-09-06','•••• 3910Mk Barreiros Israel','Israel',NULL,17.00,9,2025),(9815,1,'2025-09-06','•••• 3910Panificadora Pao e Son Familia','Familia',NULL,5.39,9,2025),(9816,1,'2025-09-07','•••• 3910Cappta *Restaurante Tropical Familia','Familia',NULL,139.00,9,2025),(9817,1,'2025-09-07','•••• 3910Super A Atacadista Familia','Familia',NULL,70.68,9,2025),(9818,1,'2025-09-08','•••• 3910The Best Acai Israel','Israel',NULL,15.80,9,2025),(9819,1,'2025-09-08','•••• 5434Dl*99 Ride','Israel',NULL,28.90,9,2025),(9820,1,'2025-09-08','•••• 3910Padaria Rei Arthur Familia','Familia',NULL,13.19,9,2025),(9821,1,'2025-09-08','•••• 6566The Best Acai Denise','Denise',NULL,8.67,9,2025),(9822,1,'2025-09-09','•••• 3910Gdi Comercio de Combus','Israel',NULL,8.99,9,2025),(9823,1,'2025-09-09','•••• 3910Restaurante Tropical Familia','Familia',NULL,118.00,9,2025),(9824,1,'2025-09-10','•••• 3910Giassi Supermercados Familia','Familia',NULL,114.08,9,2025),(9825,1,'2025-09-10','•••• 3910Santa Apolonia Denise - Parcela 1/2','Denise','Parcela 1/2',217.05,9,2025),(9826,1,'2025-09-10','•••• 3910Postos Ultra Israel','Israel',NULL,13.98,9,2025),(9827,1,'2025-09-11','•••• 3910Prado Supermercado Familia','Familia',NULL,14.98,9,2025),(9828,1,'2025-09-11','•••• 2393Sim.Digital Familia','Familia',NULL,129.80,9,2025),(9829,1,'2025-09-12','•••• 3910Arena Kobrasol Denise','Denise',NULL,5.00,9,2025),(9830,1,'2025-09-12','•••• 3910Postos Ultra Israel','Israel',NULL,19.98,9,2025),(9831,1,'2025-09-12','•••• 6566Giassi Supermercados Familia','Familia',NULL,54.12,9,2025),(9832,1,'2025-09-12','•••• 3910Restaurante Tropical Familia','Familia',NULL,30.00,9,2025),(9833,1,'2025-09-12','•••• 3910Fort Atacadista Familia','Familia',NULL,20.77,9,2025),(9834,1,'2025-09-13','•••• 3910Zp*Panificadora e Conf Familia','Familia',NULL,23.34,9,2025),(9835,1,'2025-09-13','•••• 3910Prado Supermercado Familia','Familia',NULL,57.19,9,2025),(9836,1,'2025-09-14','•••• 2144Google Deepsearch Ai Israel','Israel',NULL,10.99,9,2025),(9837,1,'2025-09-15','•••• 3910Itg - Shopping Itaguac Familia','Familia',NULL,6.00,9,2025),(9838,1,'2025-09-15','•••• 3910Quiosque.Shoppingitagu Denise','Denise',NULL,97.90,9,2025),(9839,1,'2025-09-15','•••• 3910Lojas Americanas Familia','Familia',NULL,8.99,9,2025),(9840,1,'2025-09-15','•••• 5434Pg *99 Ride Israel','Israel',NULL,30.80,9,2025),(9841,1,'2025-09-15','•••• 3910Posto Motorhome Familia','Familia',NULL,65.90,9,2025),(9842,1,'2025-09-15','•••• 391057938366airton - Israel','Israel',NULL,10.00,9,2025),(9843,1,'2025-09-15','•••• 3910Itaguacu Administrado Familia','Familia',NULL,16.00,9,2025),(9844,1,'2025-09-15','•••• 3910Sae- Bobs Israel','Israel',NULL,20.90,9,2025),(9845,1,'2025-09-16','•••• 3910Zp*Restaurante Tropica Familia','Familia',NULL,87.00,9,2025),(9846,1,'2025-09-16','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,4.99,9,2025),(9847,1,'2025-09-16','•••• 3910Mesa Posta Cafe Israel','Israel',NULL,5.00,9,2025),(9848,1,'2025-09-16','•••• 6566Restaurante Israel','Israel',NULL,4.00,9,2025),(9849,1,'2025-09-16','•••• 3910Sao Joao Farmacias Israel','Israel',NULL,39.90,9,2025),(9850,1,'2025-09-17','•••• 4927Cobasi Barreiros Familia - Parcela 1/3','Familia','Parcela 1/3',131.08,9,2025),(9851,1,'2025-09-18','Transação de NuTag','Israel',NULL,2.40,9,2025),(9852,1,'2025-09-18','Transação de NuTag','Israel',NULL,5.70,9,2025),(9853,1,'2025-09-18','•••• 3910Giassi Supermercados Familia','Familia',NULL,124.66,9,2025),(9854,1,'2025-09-18','Transação de NuTag','Israel',NULL,2.40,9,2025),(9855,1,'2025-09-18','Transação de NuTag','Israel',NULL,2.40,9,2025),(9856,1,'2025-09-18','Transação de NuTag','Israel',NULL,5.70,9,2025),(9857,1,'2025-09-18','Transação de NuTag','Israel',NULL,2.40,9,2025),(9858,1,'2025-09-19','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,13.98,9,2025),(9859,1,'2025-09-20','•••• 3910Postos Ultra Israel','Israel',NULL,16.98,9,2025),(9860,1,'2025-09-21','•••• 5434Pg *99 Ride Israel','Israel',NULL,30.10,9,2025),(9861,1,'2025-09-21','•••• 3910Giassi Supermercados Familia','Familia',NULL,31.90,9,2025),(9862,1,'2025-09-21','•••• 3910Primaveractnbrp Madero Familia','Familia',NULL,83.00,9,2025),(9863,1,'2025-09-21','•••• 3910Loja de Conveniencias Israel','Israel',NULL,6.00,9,2025),(9864,1,'2025-09-22','Nu Seguro Vida','Israel',NULL,20.74,9,2025),(9865,1,'2025-09-22','•••• 3910Restaurante Estacao Israel','Israel',NULL,51.90,9,2025),(9866,1,'2025-09-22','•••• 3910Havan Sao Jose Bela Familia - Parcela 1/5','Familia','Parcela 1/5',32.02,9,2025),(9867,1,'2025-09-22','•••• 3910Restaurante Estacao Denise','Denise',NULL,25.54,9,2025),(9868,1,'2025-09-22','•••• 6566Mp *Shellbox Familia','Familia',NULL,232.36,9,2025),(9869,1,'2025-09-22','•••• 3127Vindi *Lojab2cstore Denise - Parcela 1/6','Denise','Parcela 1/6',50.65,9,2025),(9870,1,'2025-09-23','•••• 2458Google Youtubepremium Familia','Familia',NULL,16.90,9,2025),(9871,1,'2025-09-23','•••• 3910Antecipada - Havan Sao Jose Bela Familia - Parcela 4/5','Familia','Parcela 4/5',31.99,9,2025),(9872,1,'2025-09-23','Desconto Antecipação Havan Sao Jose Bela Familia','Familia',NULL,-2.65,9,2025),(9873,1,'2025-09-23','•••• 3910Antecipada - Havan Sao Jose Bela Familia - Parcela 3/5','Familia','Parcela 3/5',31.99,9,2025),(9874,1,'2025-09-23','•••• 3910Antecipada - Havan Sao Jose Bela Familia - Parcela 2/5','Familia','Parcela 2/5',31.99,9,2025),(9875,1,'2025-09-23','•••• 3910Antecipada - Havan Sao Jose Bela Familia - Parcela 5/5','Familia','Parcela 5/5',31.99,9,2025),(9876,1,'2025-09-23','Estorno PIX RecargaPay - Sem taxa devolvida - Israel','Israel',NULL,-20.00,9,2025),(9877,1,'2025-09-23','•••• 6566Cal Dog Familia','Familia',NULL,30.00,9,2025),(9878,1,'2025-09-23','•••• 6566Mercadolivre 240 Ecomev NAC Israel','Israel',NULL,78.70,9,2025),(9879,1,'2025-09-23','•••• 3910Gdi Comercio de Combus Israel','Israel',NULL,10.99,9,2025),(9880,1,'2025-09-24','•••• 3910Postos Ultra Israel','Israel',NULL,13.98,9,2025),(9881,1,'2025-09-24','•••• 3910Arena Kobrasol Denise','Denise',NULL,5.00,9,2025),(9882,1,'2025-09-24','•••• 0187Tiktok 180 Picolinato de Cromo Israel - Parcela 1/5','Israel','Parcela 1/5',10.72,9,2025),(9883,1,'2025-09-24','•••• 3910Giassi Supermercados Familia','Familia',NULL,250.73,9,2025),(9884,1,'2025-09-24','•••• 3910Minimercado Fronza Água Familia','Familia',NULL,16.00,9,2025),(9885,1,'2025-09-25','•••• 6566Mundocar Familia','Familia',NULL,1.00,9,2025),(9886,1,'2025-09-25','•••• 6566Mercadolivre 240 Citicolina Israel - Parcela 1/5','Israel','Parcela 1/5',32.00,9,2025),(9887,1,'2025-09-25','•••• 9800Mercadolivre Arquivo Israel - Parcela 1/6','Israel','Parcela 1/6',57.70,9,2025),(9888,1,'2025-09-26','•••• 9800Mercadolivre Arquivo Israel','Israel',NULL,631.54,9,2025),(9889,1,'2025-09-26','•••• 6566Rest e Lanch Elohin Familia','Familia',NULL,5.50,9,2025),(9890,1,'2025-09-27','•••• 3910Prado Supermercado Familia','Familia',NULL,115.86,9,2025),(9891,1,'2025-09-27','•••• 3910Rest e Lanch Elohin Israel','Israel',NULL,13.00,9,2025),(9892,1,'2025-09-29','•••• 2968Tokio Marine*Vidi05d12 Israel','Israel',NULL,42.45,9,2025),(9893,1,'2025-09-29','•••• 6566Correio*Correios Denise','Denise',NULL,30.00,9,2025),(9894,1,'2025-09-30','•••• 5434Uber Israel','Israel',NULL,26.57,9,2025),(9895,1,'2025-09-30','•••• 3910Valdetepaesmarcon Israel','Israel',NULL,7.00,9,2025),(9896,1,'2025-09-30','•••• 3910Giassi Supermercados Familia','Familia',NULL,160.11,9,2025),(9897,1,'2025-09-30','•••• 3910Restaurante Geppetto Israel','Israel',NULL,4.00,9,2025),(9898,1,'2025-10-01','•••• 6566Mercadolivre*Mercadol Denise','Denise',NULL,99.28,9,2025),(9899,1,'2025-10-02','•••• 6566Ec *Shellbox Familia','Familia',NULL,152.68,9,2025),(9900,1,'2025-09-23','Desconto Antecipação PIX RecargaPay Israel','Israel',NULL,-1.03,9,2025),(9901,1,'2025-09-23','PIX RecargaPay - Israel','Israel','Parcela 1/1',21.75,9,2025);
/*!40000 ALTER TABLE `card_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_cards`
--

DROP TABLE IF EXISTS `credit_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_cards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) NOT NULL,
  `card_brand` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_cards`
--

LOCK TABLES `credit_cards` WRITE;
/*!40000 ALTER TABLE `credit_cards` DISABLE KEYS */;
INSERT INTO `credit_cards` VALUES (1,'Nubank Familia','Mastercard'),(2,'Amazon Card','Mastercard'),(3,'Nubank Denise','Mastercard');
/*!40000 ALTER TABLE `credit_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `establishment` varchar(255) NOT NULL,
  `debtor` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pago','pendente','vencido') NOT NULL DEFAULT 'pendente',
  `receipt_path` varchar(512) DEFAULT NULL,
  `transaction_month` int NOT NULL,
  `transaction_year` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (4,'2025-10-07','Sim Digital - No cartão Nubank','Familia',0.00,'pago','../envios/despesas/2025/outubro/68e5863f4f0ee-SimDigital-Comprovante.pdf',10,2025),(6,'2025-10-09','Uber','Israel',0.00,'pago',NULL,10,2025);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `family_split_config`
--

DROP TABLE IF EXISTS `family_split_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `family_split_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `israel_percentage` decimal(5,2) NOT NULL DEFAULT '50.00',
  `denise_percentage` decimal(5,2) NOT NULL DEFAULT '50.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family_split_config`
--

LOCK TABLES `family_split_config` WRITE;
/*!40000 ALTER TABLE `family_split_config` DISABLE KEYS */;
INSERT INTO `family_split_config` VALUES (1,50.00,50.00,'2025-10-06 01:22:55','2025-10-06 01:22:55');
/*!40000 ALTER TABLE `family_split_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vendor` varchar(255) NOT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `invoice_date` date NOT NULL,
  `status` enum('pago','pendente','vencido','a-vencer') NOT NULL DEFAULT 'pendente',
  `amount` decimal(10,2) NOT NULL,
  `devedor` varchar(255) DEFAULT NULL,
  `file_path` varchar(512) DEFAULT NULL,
  `receipt_path` varchar(512) DEFAULT NULL,
  `boleto_path` varchar(512) DEFAULT NULL,
  `upload_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (147,'Condominio - Fatura - 10-09-2025','Condominio - Fatura - 10-09-2025.pdf','2025-09-10','pago',1088.83,'Familia','../envios/2025/setembro/68e3e7f183117-Condominio-Fatura-10-09-2025.pdf','../envios/2025/setembro/68e3e87620295-Condominio-Comprovante-10-09-2025.jpeg',NULL,'2025-10-06 16:01:53','2025-10-06'),(148,'Unifique - Fatura e Boleto - 10-09-2025','Unifique - Fatura e Boleto - 10-09-2025.pdf','2025-09-10','pago',79.91,'Familia','../envios/2025/setembro/68e3e7f18dc6e-Unifique-FaturaeBoleto-10-09-2025.pdf','../envios/2025/setembro/68e3e87eeb521-Unifique-Comprovante-10-09-2025.jpeg',NULL,'2025-10-06 16:01:53','2025-10-06'),(149,'Amazon Card - Fatura - 10-09-2025','Amazon Card - Fatura - 10-09-2025.pdf','2025-09-10','pago',127.16,NULL,'../envios/2025/setembro/68e3e7f194fd4-AmazonCard-Fatura-10-09-2025.pdf','../envios/2025/setembro/68e3e886709b9-AmazonCard-Comprovante-10-09-2025.jpeg',NULL,'2025-10-06 16:01:53','2025-10-06'),(150,'Gas - Boleto e Fatura - 10-09-2025','Gas - Boleto e Fatura - 10-09-2025.pdf','2025-09-10','pago',185.16,'Familia','../envios/2025/setembro/68e3e7f19b4bb-Gas-BoletoeFatura-10-09-2025.pdf','../envios/2025/setembro/68e3e88f26ecb-Gas-Comprovante-10-09-2025.jpeg',NULL,'2025-10-06 16:01:53','2025-10-06'),(151,'Tim - Fatura - 10-09-2025','Tim - Fatura - 10-09-2025.pdf','2025-09-10','pago',46.99,'Israel','../envios/2025/setembro/68e3e7f1a53ea-Tim-Fatura-10-09-2025.pdf','../envios/2025/setembro/68e3e898486fd-Tim-Comprovante-10-09-2025.jpeg',NULL,'2025-10-06 16:01:53','2025-10-06'),(152,'Celesc - Fatura - 10-09-2025','Celesc - Fatura - 10-09-2025.pdf','2025-09-10','pago',198.13,'Familia','../envios/2025/setembro/68e3e7f1a7abf-Celesc-Fatura-10-09-2025.pdf','../envios/2025/setembro/68e3e8a0229ac-Celesc-Comprovante-10-09-2025.jpeg',NULL,'2025-10-06 16:01:53','2025-10-06'),(153,'Nubank Familia - Fatura - 10-09-2025','Nubank Familia - Fatura - 10-09-2025.pdf','2025-09-10','pago',12303.87,NULL,'../envios/2025/setembro/68e3e7f1ad143-NubankFamilia-Fatura-10-09-2025.pdf','../envios/2025/setembro/68e3e8a902832-NubankFamilia-Comprovante-10-09-2025.jpeg',NULL,'2025-10-06 16:01:53','2025-10-06'),(156,'TIM - Fatura - 10-10-2025','TIM - Fatura - 10-10-2025.pdf','2025-10-10','pago',46.99,'Israel','../envios/2025/outubro/68e40296b7697-TIM-Fatura-10-10-2025.pdf','../envios/2025/outubro/68e7ee69e8f7d-Tim-Comprovante-10-10-2025.jpeg',NULL,'2025-10-06 17:55:34','2025-10-09'),(157,'Unifique - Fatura - 10-10-2025','Unifique - Fatura - 10-10-2025.pdf','2025-10-10','pago',79.91,'Familia','../envios/2025/outubro/68e40296c1530-Unifique-Fatura-10-10-2025.pdf','../envios/2025/outubro/68e7ec5ff021f-Unifique-Comprovante-10-10-2025.jpeg',NULL,'2025-10-06 17:55:34','2025-10-09'),(158,'Elo Card - Fatura - 11-10-2025','Elo Card - Fatura - 11-10-2025.pdf','2025-10-11','pago',10.50,'Familia','../envios/2025/outubro/68e40296c8d12-EloCard-Fatura-11-10-2025.pdf','../envios/2025/outubro/68e7ede444b4d-elo-Comprovante-11-10-2025.jpeg',NULL,'2025-10-06 17:55:34','2025-10-09'),(160,'Nubank Familia - Fatura - 10-10-2025','Nubank Familia - Fatura - 10-10-2025.pdf','2025-10-10','pago',11791.51,NULL,'../envios/2025/outubro/68e40296da5d4-NubankFamilia-Fatura-10-10-2025.pdf','../envios/2025/outubro/68e7e880499cf-NubankFamilia-Comprovante-10-10-2025.jpeg','../envios/2025/outubro/68e7e8ad4829d-NubankFamilia-Boleto-10-10-2025.pdf','2025-10-06 17:55:34','2025-10-09'),(161,'Condomínio - Fatura - 10-10-2025','Condomínio - Fatura - 10-10-2025.pdf','2025-10-10','pago',1052.77,'Familia','../envios/2025/outubro/68e5359b8cf85-Condomnio-Fatura-10-10-2025.pdf','../envios/2025/outubro/68e7ea2da502f-Condominio-Comprovante-10-10-2025.jpeg',NULL,'2025-10-07 15:45:31','2025-10-09'),(162,'Gas - Boleto e Fatura - 10-10-2025','Gas - Boleto e Fatura - 10-10-2025.pdf','2025-10-10','pago',295.29,'Familia','../envios/2025/outubro/68e5641e04853-Gas-BoletoeFatura-10-10-2025.pdf','../envios/2025/outubro/68e7eb2c88e43-Gas-Comprovante-10-10-2025.jpeg',NULL,'2025-10-07 19:03:58','2025-10-09'),(163,'Celesc - Fatura - 10-10-2025','Celesc - Fatura - 10-10-2025.pdf','2025-10-10','pago',136.22,'Familia','../envios/2025/outubro/68e56421617bd-Celesc-Fatura-10-10-2025.pdf','../envios/2025/outubro/68e7ebd05751f-Celesc-Comprovante-10-10-2025.jpeg',NULL,'2025-10-07 19:04:01','2025-10-09'),(164,'Amazon Brascard - Fatura - 10-10-2025','Amazon Brascard - Fatura - 10-10-2025.pdf','2025-10-10','pago',127.16,NULL,'../envios/2025/outubro/68e564b1655b6-AmazonBrascard-Fatura-10-10-2025.pdf','../envios/2025/outubro/68e7ed2847853-Amazon-Comprovante-10-10-2025.jpeg',NULL,'2025-10-07 19:06:25','2025-10-09'),(165,'Condominio - Fatura - 10-11-2025','Condominio - Fatura - 10-11-2025.pdf','2025-11-10','pendente',1070.98,'Familia','../envios/2025/novembro/68ff791ae9572-Condominio-Fatura-10-11-2025.pdf',NULL,NULL,'2025-10-27 13:52:26',NULL),(166,'Elo - Fatura - 11-11-2025','Elo - Fatura - 11-11-2025.pdf','2025-11-11','pendente',0.00,'Familia','../envios/2025/novembro/690114cb0c133-Elo-Fatura-11-11-2025.pdf',NULL,NULL,'2025-10-28 19:08:59',NULL),(167,'Nubank Familia - Fatura - 10-11-2025','Nubank_2025-11-10.pdf','2025-11-10','pendente',9749.75,NULL,'../envios/2025/novembro/69088cc031954-Nubank_2025-11-10.pdf',NULL,NULL,'2025-11-03 11:06:40',NULL);
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `loan_date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `lender` varchar(100) DEFAULT NULL COMMENT 'Quem emprestou o dinheiro',
  `borrower` varchar(100) DEFAULT NULL COMMENT 'Quem pegou o dinheiro emprestado',
  `amount` decimal(10,2) NOT NULL,
  `status` enum('ativo','pago','atrasado') NOT NULL DEFAULT 'ativo',
  `due_date` date DEFAULT NULL,
  `loan_month` int NOT NULL,
  `loan_year` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
INSERT INTO `loans` VALUES (1,'2025-10-09','Fechamento inicial','Denise','Israel',504.98,'ativo',NULL,10,2025),(2,'2025-10-09','Fechamento habitacional ','Denise','Israel',380.69,'ativo',NULL,10,2025);
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminders_status`
--

DROP TABLE IF EXISTS `reminders_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminders_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reminder_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status_month` int NOT NULL,
  `status_year` int NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '0=pendente, 1=adicionada, 2=paga',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reminder_period` (`reminder_name`,`status_month`,`status_year`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminders_status`
--

LOCK TABLES `reminders_status` WRITE;
/*!40000 ALTER TABLE `reminders_status` DISABLE KEYS */;
INSERT INTO `reminders_status` VALUES (1,'Condomínio',10,2025,2),(5,'Condomínio',9,2025,2),(7,'Celesc',9,2025,2),(9,'Gás',9,2025,2),(11,'Unifique',9,2025,2),(13,'Amazon Card',9,2025,2),(15,'TIM',9,2025,2),(17,'Nubank',9,2025,2),(23,'Sim Digital',9,2025,2),(41,'TIM',10,2025,2),(42,'Unifique',10,2025,2),(43,'Nubank',10,2025,2),(47,'Sim Digital',10,2025,2),(53,'Celesc',10,2025,2),(54,'Gás',10,2025,2),(55,'Amazon Card',10,2025,2),(83,'Elo Card',10,2025,2),(85,'Elo Card',9,2025,2);
/*!40000 ALTER TABLE `reminders_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revenues`
--

DROP TABLE IF EXISTS `revenues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revenues` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `establishment` varchar(255) NOT NULL,
  `debtor` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `is_salary` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('recebido','a receber') NOT NULL DEFAULT 'a receber',
  `receipt_path` varchar(512) DEFAULT NULL,
  `transaction_month` int NOT NULL,
  `transaction_year` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revenues`
--

LOCK TABLES `revenues` WRITE;
/*!40000 ALTER TABLE `revenues` DISABLE KEYS */;
INSERT INTO `revenues` VALUES (16,'2025-10-09','Pix','Denise',4495.02,1,'recebido',NULL,10,2025),(17,'2025-10-09','Pedagio pai','Israel',21.00,0,'recebido',NULL,10,2025),(18,'2025-10-09','Empréstimo pela Denise','Israel',504.98,0,'recebido',NULL,10,2025),(19,'2025-10-09','Salario - BRD - PIX e por fora','Israel',8547.52,1,'recebido',NULL,10,2025),(21,'2025-11-01','Salario Israel','Israel',3498.86,1,'a receber',NULL,11,2025),(22,'2025-11-01','Salario Denise','Denise',3234.78,1,'a receber',NULL,11,2025);
/*!40000 ALTER TABLE `revenues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salaries`
--

DROP TABLE IF EXISTS `salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salaries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `debtor_name` varchar(100) NOT NULL,
  `salary_amount` decimal(10,2) NOT NULL,
  `salary_month` int NOT NULL,
  `salary_year` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `debtor_period` (`debtor_name`,`salary_month`,`salary_year`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salaries`
--

LOCK TABLES `salaries` WRITE;
/*!40000 ALTER TABLE `salaries` DISABLE KEYS */;
INSERT INTO `salaries` VALUES (8,'Israel',3498.86,10,2025),(10,'Denise',4495.02,10,2025),(14,'Israel',3498.86,11,2025),(15,'Denise',3234.78,11,2025);
/*!40000 ALTER TABLE `salaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('debtor_names','Israel,Denise,Familia'),('include-taxes','false'),('notify-overdue','true'),('split_familia_analytics','true'),('sum-option-1','true'),('sum-option-2','true');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `google_auth_secret` varchar(255) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `nivel` enum('administrador','tecnico','operador') NOT NULL DEFAULT 'operador',
  `status` enum('ativo','inativo') NOT NULL DEFAULT 'ativo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'israelborges','$2y$12$NuI8oJ2cZPQvphJv139bOex.ItACrCevTxOmKGxcFiawPBreUi4LW','FQKAO2OVNCO7AMM7N6Y3OA3IGNXF44IY','Israel Apolinario Borges','administrador','ativo','2025-10-08 00:00:00'),(2,'denise','$2y$12$dtIltGp.XH8a603mY0gGgOxkruKYlXo6kBN1AvhX74WjXTWAQJoMO','THPNBBGOYOESHMHFHBQQHBFW7BMGF2TF','Denise Gonçalves Borges','operador','ativo','2025-10-08 20:07:49');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-03 19:05:01
